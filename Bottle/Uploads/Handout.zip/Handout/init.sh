#!/bin/bash

# Check if the DF environment variable is set
if [ -z "$DF" ]; then
    # If DF is not set, write the default flag to flag.txt in the app's directory
    echo "flag{test}" > flag.txt
else
    # If DF is set, write its value to flag.txt
    echo "$DF" > flag.txt
fi
# Unset the DF variable to clean up the environment
unset DF

set -e

# Start the Bottle app
cd /app/bottle-note-app
python app.py &

# Start the bot app
cd /app/bot/bot
node index.js &

# Wait for both background jobs
wait -n
